JAVA Hello
==============
Este proyecto es simplemente un hola mundo de una aplicación web en Java utilizando
Spring MVC.
Para poder utilizarlo hay que desplegarlo en un Tomcat y acceder a:
http://localhost:8080/hello-java-0.1.0/greeting
Con el parámetro name se puede indicar el nombre de a quien saluda:
http://localhost:8080/hello-java-0.1.0/greeting?name=egc

